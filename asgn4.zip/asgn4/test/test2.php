<?php
    $y = 10;
    
    switch ($y) {
        case 1 :
            $y = 1;
            break;
        case 2 :
            $y = 2;
            break;    
        default:
            $y = 3;
            break;
    }
    $y = 10;
?>