<?php

    $a = 30;
    if ($a == 5):
        $a = $a*5;
    elseif ($a == 6):
        $a = $a*6;
    else:
        $a = $a*30;
    endif;

    $y = 11;
    if($y == 0){
        $y += 4;
    }elseif($y != 0){
	        $y -= 1;
    }	
	$y = 10;
 ?>
