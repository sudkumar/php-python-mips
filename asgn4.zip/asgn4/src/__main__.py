#!/usr/bin/python


from parser import runIR
import sys
 
if __name__ == '__main__':
    runIR()
